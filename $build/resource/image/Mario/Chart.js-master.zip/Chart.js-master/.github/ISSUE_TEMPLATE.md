<!--
  Need help or support? Don't open an issue!
  Head to https://stackoverflow.com/questions/tagged/chart.js

  Ahoy!

  You're seeing this because you felt none of the other options fit the type of
  issue you'd like to create. Please use this opportunity to tell us about the
  type of issue you were looking for, so we can try to accommodate similar
  issues in the future.

  If you're using this template to report an issue covered by an existing issue
  type, we'll close it as invalid faster than you can spell 'Mississippi'.
-->
